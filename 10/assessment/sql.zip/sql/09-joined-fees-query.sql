SELECT
  customers.name,
  invoices.invoice_number,
  fees.description,
  fees.amount
FROM
  invoices
  JOIN customers ON customers.id = invoices.customer_id
  JOIN fees ON fees.invoice_id = invoices.id
ORDER BY
  customers.name;
