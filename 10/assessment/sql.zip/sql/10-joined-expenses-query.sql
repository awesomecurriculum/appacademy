SELECT
  customers.name,
  invoices.invoice_number,
  expenses.description,
  expenses.number_of_units,
  expenses.rate
FROM
  invoices
  JOIN customers ON customers.id = invoices.customer_id
  JOIN expenses ON expenses.invoice_id = invoices.id
ORDER BY
  customers.name;
