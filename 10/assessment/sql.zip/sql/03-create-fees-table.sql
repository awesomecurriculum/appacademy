CREATE TABLE fees (
  id serial PRIMARY KEY NOT NULL,
  description varchar(100) NOT NULL,
  amount numeric(10, 3) NOT NULL,
  invoice_id integer REFERENCES invoices (id) NOT NULL
);
