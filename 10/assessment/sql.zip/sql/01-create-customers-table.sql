CREATE TABLE customers (
  id serial PRIMARY KEY NOT NULL,
  name varchar(50) UNIQUE NOT NULL,
  contact_email varchar(200) UNIQUE NOT NULL
);
