CREATE TABLE invoices (
  id serial PRIMARY KEY NOT NULL,
  invoice_number varchar(20) UNIQUE NOT NULL,
  created_at timestamp NOT NULL,
  paid_on timestamp,
  customer_id integer REFERENCES customers (id) NOT NULL
);
