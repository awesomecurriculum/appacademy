// event listeners, AJAS req using fetch
// https://docs.thecatapi.com/
// https://thecatapi.com/

const root = 'http://localhost:3000/';
const pic = document.querySelector('img.cat-pic');
const newPicButton = document.querySelector('button#new-pic');
const loaderDiv = document.querySelector('div.loader');
const upvoteButton = document.querySelector('#upvote');
const downvoteButton = document.querySelector('#downvote');
const scoreSpan = document.querySelector('span.score');
const submitButton = document.querySelector('input[type="submit"]');
const commentInput = document.querySelector('input#user-comment');
const commentForm = document.querySelector('form.comment-form');
const storedComments = document.querySelector('div.comments');
const errorDiv = document.querySelector('div.error');

window.addEventListener('DOMContentLoaded', getPic);

newPicButton.addEventListener('click', getPic);

upvoteButton.addEventListener('click', upvote);

async function upvote() {
    const res = await fetch(`${root}kitten/upvote`);
    console.log(res);
    const data = await res.json()
});
} ///v v v nice working with you dude, sorry the end got a little muddy!!!
just seeing this now - awesome working with you too! haha not at all it was coming togther!

downvoteButton.addEventListener('click', changeScore);

commentForm.addEventListener('submit', e => {
    e.preventDefault();
    storedComments.appendChild(document.createElement('div')).innerHTML = commentInput.value;
    commentForm.reset();
});

function changeScore(e) {
    e.target.id === 'downvote' ? scoreSpan.innerText-- : scoreSpan.innerText++;
}

async function getPic() {
    try {
        loaderDiv.classList.remove('hide');
        const res = await fetch(`${root}kitten/image`);
        const kittenObj = await res.json();
        loaderDiv.classList.add('hide');
        if (!res.ok) {
            throw kittenObj.message;
        } else {
            pic.setAttribute('src', kittenObj.src);
        }
    } catch (message) {
        errorDiv.innerHTML = message;
    }
}
