# OAuth 2.0 Demo

See [app.js] and the comments

[app.js]: ./app.js