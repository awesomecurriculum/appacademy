import { Board } from './Board.js';
import { Load } from './Load.js';

window.addEventListener('DOMContentLoaded', _ => {
  if (localStorage.length > 0) {
    const load = new Load();
    load.go();
  } else {
    const board = new Board();
    board.go();
  }
});
