export class Opponent {
  constructor() {
    this.board = null;
    this.open = null;
    this.listener = null;
  }

  go(board) {
    this.board = board;
  }

  updateOpen() {
    this.open = document.querySelectorAll('.open');
  }

  getRandomNum() {
    return Math.floor(Math.random() * Math.floor(this.open.length));
  }

  pause(player) {
    this.updateOpen();
    const num = this.getRandomNum();
    const ele = this.open[num];
    this.capturePlay(ele, player);
  }

  play(player) {
    this.listener = this.pause.bind(this);
    setTimeout(this.listener, 1500, player);
  }

  capturePlay(ele, player) {
    const row = ele.classList[1];
    const col = ele.classList[2];
    const id = ele.id;
    const p = [row, col, id, player];
    this.board.processPlay(p);
  }
}
