export class Game {
  constructor(mode) {
    this['row-1'] = [];
    this['col-1'] = [];
    this['row-2'] = [];
    this['col-2'] = [];
    this['row-3'] = [];
    this['col-3'] = [];
    this.mode = mode;
    this.topDownDiag = [];
    this.bottomUpDiag = [];
    this.plays = [];
    this.result = '';
    this.player = '';
    this.playsLeft = 9;
  }

  savePlay(p) {
    this.player = p[3];
    this[p[0]].push(p[3]);
    this[p[1]].push(p[3]);
    this.pushToDiag(p);
    this.plays.push(p);
    this.managePlays();
  }

  managePlays() {
    this.playsLeft--;
    this.storePlays();
    this.checkForResult();
  }

  storePlays() {
    localStorage.setItem('plays', JSON.stringify(this.plays));
  }

  pushToDiag(p) {
    if (p[2].includes(4)) {
      this.topDownDiag.push(p[3]);
      this.bottomUpDiag.push(p[3]);
    } else if (p[2].includes(0) || p[2].includes(8)) {
      this.topDownDiag.push(p[3]);
    } else if (p[2].includes(2) || p[2].includes(6)) {
      this.bottomUpDiag.push(p[3]);
    }
  }

  checkForResult() {
    this.checkForWinner().length > 0 ? (this.result = this.player) : this.checkForTie() ? (this.result = 'None') : (this.result = '');
  }

  checkForWinner() {
    return Object.getOwnPropertyNames(this).filter(ele => this[ele].length === 3 && this[ele].every(p => p === this.player));
  }

  checkForTie() {
    return this.playsLeft === 0;
  }
}
