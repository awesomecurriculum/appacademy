export class Ui {
  constructor() {
    this.header = document.getElementById('game-status');
    this.images = {
      x: '../images/player-x.svg',
      o: '../images/player-o.svg',
    };
  }

  updateHeader(result) {
    this.header.innerHTML = `Winner: ${result.toUpperCase()}`;
  }

  showPlay(id, player) {
    let src = this.images[player];
    let ele = document.getElementById(id);
    let img = document.createElement('img');
    img.setAttribute('src', `${src}`);
    ele.append(img);
  }

  showStartButtons() {
    document.querySelectorAll('.start').forEach(b => {
      b.classList.remove('hide');
      b.classList.add('show');
    });

    document.querySelectorAll('.end').forEach(b => {
      b.classList.remove('show');
      b.classList.add('hide');
    });
  }

  showEndButtons() {
    document.querySelectorAll('.end').forEach(b => {
      b.classList.remove('hide');
      b.classList.add('show');
    });

    document.querySelectorAll('.start').forEach(b => {
      b.classList.remove('show');
      b.classList.add('hide');
    });
  }
}
