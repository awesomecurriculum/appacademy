import { Ui } from './Ui.js';
import { Opponent } from './Opponent.js';
import { Game } from './Game.js';

export class Board {
  constructor(mode = null) {
    this.mode = mode;
    this.player = 'x';
    this.computer = '';
    this.game = null;
    this.openSquares = null;
    this.opponent = null;
    this.eles = this.setEles();
    this.listeners = this.setListeners(this);
    this.ui = new Ui();
  }

  setEles() {
    return {
      friend: document.getElementById('play-friend'),
      computer: document.getElementById('play-computer'),
      newGame: document.getElementById('new-game'),
      giveUp: document.getElementById('give-up'),
      board: document.getElementById('tic-tac-toe-board'),
    };
  }

  setListeners(board) {
    return {
      friend: board.handleFriend.bind(board),
      computer: board.handleComputer.bind(board),
      newGame: board.handleNewGame.bind(board),
      giveUp: board.handleGiveUp.bind(board),
      board: board.handlePlay.bind(board),
    };
  }

  preventNewPlay(boo) {
    if (boo) this.eles.board.removeEventListener('click', this.listeners.board);
    else this.eles.board.addEventListener('click', this.listeners.board);
  }

  go() {
    Object.keys(this.eles).forEach(ele => this.eles[ele].addEventListener('click', this.listeners[ele]));
    document.querySelectorAll('.square').forEach(ele => ele.classList.add('open'));
    if (this.mode) this.startGame(this.mode);
    else {
      this.ui.showStartButtons();
      this.preventNewPlay(true);
    }
  }

  startGame(mode) {
    this.mode = mode;
    this.game = new Game(mode);

    localStorage.setItem('mode', JSON.stringify(mode));
    this.ui.showEndButtons();
    this.enableButton(this.eles.giveUp);
    this.disableButton(this.eles.newGame);
    this.preventNewPlay(false);

    if (mode === 'computer') this.challengeOpponent();
  }

  challengeOpponent() {
    this.opponent = new Opponent();
    this.opponent.go(this);
  }

  handleComputer() {
    this.computer = 'o';
    this.startGame('computer');
  }

  handleFriend() {
    this.startGame('friend');
  }

  capturePlay(e) {
    const row = e.target.classList[1];
    const col = e.target.classList[2];
    const id = e.target.id;
    const p = [row, col, id, this.player];
    return p;
  }

  handlePlay(e) {
    const p = this.capturePlay(e);
    this.processPlay(p);
  }

  processPlay(p) {
    this.ui.showPlay(p[2], p[3]);
    this.game.savePlay(p);
    document.getElementById(`${p[2]}`).classList.remove('open');
    if (this.checkForResult()) return this.preventNewPlay(true);
    this.changePlayer();
    if (this.computer === this.player) this.tellOpponentToPlay();
    else this.preventNewPlay(false);
  }

  tellOpponentToPlay() {
    this.preventNewPlay(true);
    this.opponent.play(this.player);
  }

  checkForResult() {
    if (this.game.result) {
      this.ui.updateHeader(this.game.result);
      this.end();
      return true;
    }
  }

  changePlayer() {
    if (this.player === 'x') this.player = 'o';
    else this.player = 'x';
  }

  clearStorage() {
    localStorage.removeItem('plays');
    localStorage.removeItem('mode');
  }

  end() {
    this.preventNewPlay();
    this.clearStorage();
    this.enableButton(this.eles.newGame);
    this.disableButton(this.eles.giveUp);
    return;
  }

  enableButton(b) {
    b.disabled = false;
  }

  disableButton(b) {
    b.disabled = true;
  }

  handleGiveUp() {
    this.changePlayer();
    this.ui.updateHeader(this.player);
    this.end();
  }

  handleNewGame() {
    location.reload();
  }
}
