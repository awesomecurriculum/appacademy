import { Board } from './Board.js';

export class Load {
  constructor() {
    this.plays = null;
    this.mode = null;
    this.board = null;
  }

  go() {
    this.setPlays();
    this.setMode();
    if (this.validateMode()) this.board = new Board(this.mode);
    else {
      localStorage.removeItem('mode');
      this.board = new Board();
    }
    this.board.go();
    this.processPlays();
  }

  setPlays() {
    this.plays = JSON.parse(localStorage.getItem('plays'));
  }

  setMode() {
    this.mode = JSON.parse(localStorage.getItem('mode'));
  }

  validateMode() {
    if (this.mode) return true;
    else return false;
  }

  processPlays() {
    this.plays.forEach((p, i) => {
      this.board.processPlay(p);
      if (i === this.plays.length - 1) this.board.computer = 'o';
    });
  }
}
