const { EntreeType, Entree } = require('./models');

const test = async () => {
  console.log(EntreeType);
  const types = await EntreeType.findAll({ order: [['name', 'asc']] });
  console.log(await types);
};

test();
