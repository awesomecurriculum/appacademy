/**
 * TODO: Create and configure your Express.js application in here.
 *       You must name the variable that contains your Express.js
 *       application "app" because that is what is exported at the
 *       bottom of the file.
 */
const express = require('express');
const csrf = require('csurf');
const port = process.env.PORT || 8081;

const { EntreeType, Entree } = require('./models');

const app = express();

const asyncHandler = handler => (req, res, next) => handler(req, res, next).catch(next);

app.set('view engine', 'pug');

const logger = require('morgan');
app.use(logger('dev'));

const cookieParser = require('cookie-parser');
app.use(cookieParser());
app.use(express.urlencoded({ extended: false }));

const csrfProtection = csrf({ cookie: true });

app.get('/', async (req, res) => {
  const entrees = await Entree.findAll({ include: EntreeType, order: [['name', 'asc']] });
  res.render('index', { title: 'Entrees', entrees });
});

app.get('/entrees/new', csrfProtection, async (req, res) => {
  const entreeTypes = await EntreeType.findAll({ order: [['name', 'asc']] });
  res.render('new-entree', {
    title: 'Create a new entree',
    csrfToken: req.csrfToken(),
    entreeTypes,
  });
});

app.post(
  '/entrees',
  csrfProtection,
  asyncHandler(async (req, res) => {
    const { name, description, price, entreeTypeId } = req.body;
    if (req.errors) {
      res.render('/entrees/new', {
        title: 'Create a new entree',
        csrfToken: req.csrfToken(),
        entreeTypes,
        name,
        description,
        price,
        entreeTypeId,
      });
    } else {
      await Entree.create({ name, description, price, entreeTypeId });
      res.redirect('/');
    }
  })
);

app.use((req, res, next) => {
  const err = new Error('This is an error message.');
  err.status = 404;
  next(err);
});

app.use((err, req, res, next) => {
  console.log(err);
  next(err);
});

app.use((err, req, res, next) => {
  if (err.status === 404) {
    res.status(404);
    res.render('errors/page-not-found', {
      title: 'Page Not Found',
    });
  } else {
    next(err);
  }
});

app.use((err, req, res, next) => {
  res.status(err.status || 500);
  res.render('errors/generic', {
    title: 'Error',
  });
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});

/* Do not change this export. The tests depend on it. */
try {
  exports.app = app;
} catch (e) {
  exports.app = null;
}
